# SIROutbreakSimulator
An SIR Disease Model and Simulation Python program
